import streamlit as st
import pandas as pd
from utils.openai_helper import generate_visualization_query
from utils.data_processor import process_data
from utils.visualization import create_visualization

# Set page configuration
st.set_page_config(
    page_title="PowerAmit - Text-to-Graph Dashboard Generator",
    page_icon="📊",
    layout="wide"
)

# Initialize session state for keeping track of data and visualizations
if 'data' not in st.session_state:
    st.session_state.data = None
if 'visualizations' not in st.session_state:
    st.session_state.visualizations = []
if 'file_name' not in st.session_state:
    st.session_state.file_name = None
if 'messages' not in st.session_state:
    st.session_state.messages = []

# Header with title
st.title("PowerAmit")

# Main container for chat-like interface
main_container = st.container()

# Sidebar for file upload
with st.sidebar:
    st.header("Upload Your Data")
    
    uploaded_file = st.file_uploader(
        "Upload a CSV or XLSX file",
        type=["csv", "xlsx"],
        help="Upload your data file to generate visualizations"
    )
    
    if uploaded_file is not None:
        try:
            # Process the uploaded file
            file_extension = uploaded_file.name.split(".")[-1]
            
            if file_extension.lower() == "csv":
                data = pd.read_csv(uploaded_file)
            elif file_extension.lower() == "xlsx":
                data = pd.read_excel(uploaded_file)
            
            # Store the data and file name in session state
            st.session_state.data = data
            st.session_state.file_name = uploaded_file.name
            
            # Display data info
            st.success(f"✅ {uploaded_file.name} loaded successfully!")
            st.write(f"**Rows:** {len(data)}, **Columns:** {len(data.columns)}")
            
            with st.expander("Preview Data"):
                st.dataframe(data.head(5))
                
            # Add a system message to the chat
            if not any(msg.get("role") == "system" and "Data loaded" in msg.get("content", "") for msg in st.session_state.messages):
                st.session_state.messages.append({"role": "system", "content": f"Data loaded: {uploaded_file.name}"})
            
        except Exception as e:
            st.error(f"Error loading file: {str(e)}")
    
    # Additional information in sidebar
    with st.expander("How to use PowerAmit"):
        st.write("""
        1. Upload your CSV or Excel file using the file uploader above
        2. Ask a question about your data in the chat input below
        3. PowerAmit will analyze your request and generate visualizations
        4. Continue the conversation to refine or create new visualizations
        """)

# Display chat messages
with main_container:
    # Display all previous messages
    for message in st.session_state.messages:
        if message["role"] == "user":
            with st.chat_message("user"):
                st.write(message["content"])
        elif message["role"] == "assistant":
            with st.chat_message("assistant"):
                st.write(message["content"])
                # If this message contains a visualization, display it
                if "visualization" in message:
                    viz = message["visualization"]
                    st.plotly_chart(viz["figure"], use_container_width=True)
        elif message["role"] == "system":
            with st.chat_message("system"):
                st.write(message["content"])

    # Chat input
    if st.session_state.data is not None:
        user_query = st.chat_input("Ask about your data or describe what visualization you'd like to see...")
        
        if user_query:
            # Add user message to chat
            st.session_state.messages.append({"role": "user", "content": user_query})
            
            # Display user message immediately
            with st.chat_message("user"):
                st.write(user_query)
            
            # Process user query with AI
            with st.chat_message("assistant"):
                with st.spinner("Thinking..."):
                    try:
                        # Get visualization details from OpenAI
                        visualization_details = generate_visualization_query(
                            user_query, 
                            st.session_state.data
                        )
                        
                        # Process data for visualization
                        processed_data = process_data(
                            st.session_state.data, 
                            visualization_details
                        )
                        
                        # Create the visualization
                        figure = create_visualization(
                            processed_data, 
                            visualization_details
                        )
                        
                        # Create response message
                        response = f"**{visualization_details['title']}**\n\n{visualization_details['description']}"
                        
                        # Display the response and visualization
                        st.write(response)
                        st.plotly_chart(figure, use_container_width=True)
                        
                        # Store the message and visualization
                        st.session_state.messages.append({
                            "role": "assistant", 
                            "content": response,
                            "visualization": {
                                "title": visualization_details["title"],
                                "description": visualization_details["description"],
                                "query": user_query,
                                "figure": figure,
                                "type": visualization_details["chart_type"]
                            }
                        })
                        
                        # Also add to visualizations collection for reference
                        st.session_state.visualizations.append({
                            "title": visualization_details["title"],
                            "description": visualization_details["description"],
                            "query": user_query,
                            "figure": figure,
                            "type": visualization_details["chart_type"]
                        })
                        
                    except Exception as e:
                        error_message = f"I'm sorry, I couldn't create a visualization based on your request. Error: {str(e)}"
                        st.error(error_message)
                        st.session_state.messages.append({"role": "assistant", "content": error_message})
    else:
        # Welcome message when no data is loaded
        st.info("👋 Welcome to PowerAmit! Please upload a data file in the sidebar to get started.")
        
        # Display some sample images in a grid
        st.write("### Here are some examples of what you can create:")
        col1, col2 = st.columns(2)
        
        with col1:
            st.image("https://pixabay.com/get/g6218f178ee6159d77b8e3c59ed4edf90df35220e7cf571295e6fac0f9cab65044fa46fe306884682c0a59aead3f4af8590ba21361f30056ed4c7d9c7a47edfd9_1280.jpg", 
                     caption="Graph Example", use_container_width=True)
        
        with col2:
            st.image("https://pixabay.com/get/gc8fb0d5a61bc0390b9ed01fa2d23d36b6bdabc6f30c264d26982526463c2703438d3e5df8b2014bb825b62ee1003e673cf3cf88709a81950358b598cdc197b58_1280.jpg", 
                     caption="Dashboard Example", use_container_width=True)

# Footer
st.divider()
st.caption("PowerAmit - Text-to-Graph Dashboard Generator | Powered by OpenAI and Streamlit")
