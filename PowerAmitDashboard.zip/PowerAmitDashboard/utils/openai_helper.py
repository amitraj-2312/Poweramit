import os
import json
import pandas as pd
from openai import OpenAI

# Initialize OpenAI client
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai = OpenAI(api_key=OPENAI_API_KEY)

def generate_visualization_query(user_query, data):
    """
    Use OpenAI to interpret a user's natural language query and generate visualization details.
    
    Args:
        user_query: User's natural language request for visualization
        data: DataFrame containing the data to be visualized
    
    Returns:
        dict: Details for creating the visualization
    """
    # Get data summary
    data_summary = _get_data_summary(data)
    
    # Prepare the prompt for OpenAI
    system_prompt = """
    You are a data visualization expert. Given a user's request and dataset information, determine the best way to visualize this data.
    Analyze the columns available and the user's request to decide:
    1. Which columns should be used for the visualization
    2. What chart type would be most appropriate (bar, line, pie, scatter, etc.)
    3. Any data transformations needed before visualization
    4. A clear title and description for the visualization
    
    IMPORTANT: Only suggest visualizations that can be created using the available columns.
    Your response should be a JSON object with the following structure:
    {
        "chart_type": "bar/line/pie/scatter/etc.",
        "title": "Clear title for the chart",
        "description": "Brief description of what the chart shows",
        "x_axis": "Column name for x-axis or categories",
        "y_axis": "Column name for y-axis or values",
        "group_by": "Optional column name to group by",
        "aggregation": "sum/mean/count/etc. or null if no aggregation needed",
        "transformations": ["list of required transformations or empty array"],
        "filters": {"column": "value"} or {} if no filters needed
    }
    """
    
    try:
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"User request: {user_query}\n\nDataset information:\n{data_summary}"}
            ],
            response_format={"type": "json_object"}
        )
        
        visualization_details = json.loads(response.choices[0].message.content)
        return visualization_details
    
    except Exception as e:
        raise Exception(f"Error generating visualization query: {str(e)}")

def _get_data_summary(data):
    """
    Generate a summary of the dataset for the OpenAI prompt.
    
    Args:
        data: DataFrame to summarize
    
    Returns:
        str: Text summary of the dataset
    """
    # Get basic dataframe info
    columns = list(data.columns)
    sample_data = data.head(3).to_dict(orient='records')
    dtypes = {col: str(data[col].dtype) for col in columns}
    
    # Create a meaningful summary
    summary = f"Number of rows: {len(data)}\n"
    summary += f"Number of columns: {len(columns)}\n"
    summary += "Columns and their data types:\n"
    
    for col, dtype in dtypes.items():
        summary += f"- {col}: {dtype}\n"
    
    summary += "\nSample data (first 3 rows):\n"
    for i, row in enumerate(sample_data):
        summary += f"Row {i+1}: {row}\n"
        
    # Add basic statistics for numerical columns
    numerical_cols = data.select_dtypes(include=['int64', 'float64']).columns.tolist()
    if numerical_cols:
        summary += "\nBasic statistics for numerical columns:\n"
        for col in numerical_cols:
            summary += f"- {col}: min={data[col].min()}, max={data[col].max()}, mean={data[col].mean()}\n"
    
    # Add information about categorical columns
    categorical_cols = data.select_dtypes(include=['object', 'category']).columns.tolist()
    if categorical_cols:
        summary += "\nCategorical columns and their unique values:\n"
        for col in categorical_cols:
            unique_values = data[col].nunique()
            if unique_values < 10:  # Only show all values if there aren't too many
                summary += f"- {col}: {data[col].unique().tolist()}\n"
            else:
                summary += f"- {col}: {unique_values} unique values\n"
    
    return summary
