import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np

def create_visualization(data, visualization_details):
    """
    Create a visualization based on the processed data and visualization details.
    
    Args:
        data: Processed DataFrame ready for visualization
        visualization_details: Dictionary containing visualization specifications
    
    Returns:
        plotly.graph_objects.Figure: The generated visualization
    """
    chart_type = visualization_details["chart_type"].lower()
    title = visualization_details["title"]
    x_axis = visualization_details["x_axis"]
    y_axis = visualization_details["y_axis"]
    
    # Get optional parameters with defaults
    group_by = visualization_details.get("group_by")
    color_column = group_by if group_by else None
    
    # Create the visualization based on chart type
    try:
        if chart_type in ["bar", "column"]:
            if group_by and group_by != x_axis:
                fig = px.bar(
                    data,
                    x=x_axis,
                    y=y_axis,
                    color=color_column,
                    title=title,
                    barmode="group"
                )
            else:
                fig = px.bar(
                    data,
                    x=x_axis,
                    y=y_axis,
                    title=title
                )
                
        elif chart_type == "line":
            fig = px.line(
                data,
                x=x_axis,
                y=y_axis,
                color=color_column,
                title=title,
                markers=True
            )
            
        elif chart_type == "pie":
            fig = px.pie(
                data,
                names=x_axis,
                values=y_axis,
                title=title
            )
            
        elif chart_type == "scatter":
            fig = px.scatter(
                data,
                x=x_axis,
                y=y_axis,
                color=color_column,
                title=title
            )
            
        elif chart_type == "area":
            fig = px.area(
                data,
                x=x_axis,
                y=y_axis,
                color=color_column,
                title=title
            )
            
        elif chart_type == "histogram":
            fig = px.histogram(
                data,
                x=x_axis,
                title=title
            )
            
        elif chart_type == "box":
            fig = px.box(
                data,
                x=x_axis,
                y=y_axis,
                color=color_column,
                title=title
            )
            
        elif chart_type == "heatmap":
            # For heatmap, reshape the data if necessary
            if len(data[x_axis].unique()) > 1 and len(data[y_axis].unique()) > 1:
                # If we have a third value column
                if group_by and group_by != x_axis and group_by != y_axis:
                    # Create a pivot table for heatmap
                    pivot_data = data.pivot_table(
                        index=y_axis, 
                        columns=x_axis, 
                        values=group_by,
                        aggfunc='mean'
                    )
                    fig = px.imshow(
                        pivot_data,
                        title=title
                    )
                else:
                    # Create a simple correlation heatmap
                    corr_data = data.corr()
                    fig = px.imshow(
                        corr_data,
                        title=title
                    )
            else:
                # Fallback to bar chart if data not suitable for heatmap
                fig = px.bar(
                    data,
                    x=x_axis,
                    y=y_axis,
                    title=title
                )
                
        else:
            # Default to bar chart for unsupported types
            fig = px.bar(
                data,
                x=x_axis,
                y=y_axis,
                title=title
            )
        
        # Customize the layout for better appearance
        fig.update_layout(
            title_x=0.5,
            xaxis_title=x_axis,
            yaxis_title=y_axis,
            legend_title=group_by if group_by else None,
            template="plotly_white"
        )
        
        return fig
        
    except Exception as e:
        # If visualization fails, create a simple error chart
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error creating visualization: {str(e)}",
            showarrow=False,
            font=dict(size=14, color="red")
        )
        fig.update_layout(title=title, title_x=0.5)
        return fig

def get_visualization_types():
    """
    Get a list of supported visualization types.
    
    Returns:
        list: Supported visualization types
    """
    return [
        "bar",
        "column",
        "line",
        "pie",
        "scatter",
        "area",
        "histogram",
        "box",
        "heatmap"
    ]
